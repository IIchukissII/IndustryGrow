/*
 * SPDX-FileCopyrightText: 2026 The IndustryGrow contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
#ifndef IGROW_CYPHAL_CYPHAL_H
#define IGROW_CYPHAL_CYPHAL_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* Cyphal node skeleton over libcanard (ADR-0005 d5): publishes
 * uavcan.node.Heartbeat at 1 Hz, answers uavcan.node.GetInfo + the register
 * interface + ExecuteCommand. That makes the node enumerate and be configurable
 * on the gateway. The per-node personality (sensor publications) sits on top
 * via cyphal_publish().
 *
 * `node_id` is the instance identity read from the carrier flash store
 * (ADR-0027 d1/d2), not a value derived from the module class. Call
 * cyphal_init() once after can_init_normal(), then cyphal_spin() as often as
 * possible from the main loop.
 *
 * `node_name` is the reverse-DNS uavcan.node.GetInfo name and `description` the
 * uavcan.node.description register. Both belong to the strap-selected
 * personality, not to the image -- one image serves every module class
 * (ADR-0017 d16), so these are how the gateway tells an E0002 from an E0006 on
 * the wire. Both must outlive the call; string literals are the intended source. */
void cyphal_init(uint8_t node_id, const char *node_name, const char *description);
void cyphal_spin(void);

/* Tell the skeleton the two independent identity answers, so it can report
 * them (ADR-0027 d6, d10). Each degrades health to ADVISORY on its own and
 * neither implies the other: a node can be provisioned with no personality, or
 * carry a personality with no Node-ID. Call once, after cyphal_init().
 *
 * An unprovisioned node also gets one diagnostic naming what is missing --
 * "an unprovisioned node must be diagnosable" is a decision driver of the ADR,
 * and health alone does not say which of the identity faults is present. */
void cyphal_report_identity(bool node_id_provisioned, bool personality_resolved);

/* Publish a pre-serialized message on `subject_id` (a Cyphal port-ID). The
 * caller owns `transfer_id` (one counter per subject) — it is post-incremented
 * and wrapped. Used by the node personality to emit sensor telemetry. */
void cyphal_publish(uint16_t subject_id, uint8_t *transfer_id,
                    const uint8_t *payload, size_t size);

/* The value to put in every uavcan.time.SynchronizedTimestamp field: the
 * network time base if this node is synchronized, otherwise 0 = UNKNOWN.
 *
 * That field is a NETWORK-wide time base, not a per-node one. The gateway is
 * the bus time-synchronization master (ADR-0002 d11) and publishes
 * uavcan.time.Synchronization on subject 7168 at least once per second; this node
 * is a slave and
 * tracks it as an OFFSET against its own monotonic clock. The local clock is
 * never stepped -- libcanard's transmission deadlines and transfer-ID timeouts
 * are denominated in it.
 *
 * Returns 0 whenever the offset is not currently trustworthy: before the first
 * pair of sync messages, and again once the master has been silent for three
 * publication periods. A stale offset reported as truth is worse than an absent
 * timestamp, because a consumer cannot detect it. Without a master, two nodes'
 * stamps share no origin at all -- node 96 at 1378 s and node 97 at 62 s were
 * describing the same instant -- and a consumer that aligns samples across
 * nodes, which is what the state estimator of ADR-0016 does, would be silently
 * wrong. That is what this exists to prevent.
 *
 * Accuracy is milliseconds, not microseconds (ADR-0002 d11): reception is
 * timestamped in the polled main loop, so the error is bounded by however long
 * a personality's blocking sensor read keeps the loop away from pump_rx().
 */
uint64_t cyphal_timestamp_usec(void);

/* Report the personality's own health for the next heartbeat. The heartbeat
 * carries the WORSE of this and the skeleton's own assessment, so a personality
 * cannot mask an identity fault and the skeleton cannot mask a sensor fault.
 * Values are uavcan.node.Health constants. Never reported means NOMINAL. */
void cyphal_set_health(uint8_t health);

/* Publish uavcan.diagnostic.Record (subject 8184) at OPTIONAL priority.
 *
 * The node is the only thing that knows why a reading failed, and until now it
 * said so on a UART that no deployment reads. Event-driven only -- a periodic
 * diagnostic is a log, and the bus is not the place for one. `severity` takes
 * uavcan.diagnostic.Severity values; text is truncated to fit the type. */
void cyphal_diagnostic(uint8_t severity, const char *text);

/* As above with an unsigned decimal appended after a space. */
void cyphal_diagnostic_u32(uint8_t severity, const char *text, uint32_t value);

/* Vendor-specific uavcan.node.ExecuteCommand handling. The standard commands
 * stay with the skeleton; anything the vendor range defines (from zero upward)
 * is offered to this handler, which returns a uavcan.node.ExecuteCommand
 * Response STATUS_* value. Unset means every vendor command is rejected.
 *
 * `param` is the request's own parameter field, for the commands that carry a
 * value rather than only an instruction -- a temperature offset to write, a
 * reference concentration to calibrate against. It is NOT NUL-terminated and is
 * borrowed for the duration of the call. `param_len` is 0 when the caller sent
 * none, which is the ordinary case.
 *
 * A command must return promptly: the response is sent from the same pass of
 * the loop, and the watchdog window is ~1.4 s at worst-case LSI. Anything
 * slower accepts the command and does the work from the personality's spin. */
typedef uint8_t (*cyphal_command_fn)(uint16_t command, const uint8_t *param, size_t param_len);
void cyphal_set_command_handler(cyphal_command_fn fn);

/* --- server side: the services a personality answers ----------------------
 *
 * The skeleton answers GetInfo, the register interface and ExecuteCommand for
 * every node. A personality may answer more: M04 serves its interval frame over
 * uavcan.file.Read and takes its flat-field trim over uavcan.file.Write
 * (ADR-0005 d11, M04 spec 6.7, 10.2).
 *
 * The request reaches the handler as its raw payload and the handler writes the
 * serialized response, because the personality is the only thing that knows the
 * type -- the same division as the response subscription below. Returning 0
 * sends nothing, which is the right answer to a request that did not
 * deserialize. `response` is CYPHAL_SERVICE_RESPONSE_MAX bytes.
 *
 * Registered services also appear in uavcan.node.port.List, so a consumer
 * discovers them rather than having to know M04 serves a file.
 */
#define CYPHAL_SERVICE_RESPONSE_MAX 320u
typedef size_t (*cyphal_service_fn)(uint8_t from_node_id,
                                    const uint8_t *request, size_t request_size,
                                    uint8_t *response, size_t response_capacity);
bool cyphal_serve(uint16_t service_id, size_t extent, cyphal_service_fn fn);

/* --- client side: the service requests this node originates ----------------
 *
 * The bootloader downloads an image with uavcan.file.Read (ADR-0029 d5), which
 * makes it a service CLIENT -- the only one in the project so far. The two
 * calls below are the whole client surface: send a request, and be told when
 * its response arrives.
 *
 * One response subscription exists, not a table: a second client would need a
 * second slot, and inventing the table before the second caller is guesswork.
 * `cyphal_subscribe_response()` replaces whatever was registered.
 *
 * A response is delivered as its raw payload -- deserialization belongs to the
 * caller, who is the only one that knows the type. Returns false when the
 * request could not be queued (a full TX queue is the realistic cause). */
typedef void (*cyphal_response_fn)(uint8_t from_node_id, uint8_t transfer_id,
                                   const uint8_t *payload, size_t size);
bool cyphal_request(uint16_t service_id, uint8_t server_node_id, uint8_t *transfer_id,
                    const uint8_t *payload, size_t size);
bool cyphal_subscribe_response(uint16_t service_id, size_t extent, cyphal_response_fn fn);

/* Restart once the TX queue and the CAN mailboxes have drained. This is how
 * ExecuteCommand RESTART is honoured, and what an update request uses after
 * recording itself (ADR-0029 d3): the response must reach the caller before
 * the node disappears. */
void cyphal_restart_after_flush(void);

/* Declare the subjects this personality publishes, for uavcan.node.port.List
 * (subject 7510). The array must outlive the call. Heartbeat and port.List
 * itself are added by the skeleton. Without this a consumer cannot discover
 * what the node emits — ADR-0005 requires the capability. */
void cyphal_declare_publishers(const uint16_t *subject_ids, uint8_t count);

#endif /* IGROW_CYPHAL_CYPHAL_H */
