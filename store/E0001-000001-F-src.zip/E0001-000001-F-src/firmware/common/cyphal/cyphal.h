/*
 * SPDX-FileCopyrightText: 2026 The IndustryGrow contributors
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
#ifndef IGROW_CYPHAL_CYPHAL_H
#define IGROW_CYPHAL_CYPHAL_H

#include <stddef.h>
#include <stdint.h>

/* Cyphal node skeleton over libcanard (ADR-0005 d5): publishes
 * uavcan.node.Heartbeat at 1 Hz, answers uavcan.node.GetInfo + the register
 * interface + ExecuteCommand. That makes the node enumerate and be configurable
 * on the gateway. The per-node personality (sensor publications) sits on top
 * via cyphal_publish().
 *
 * `node_id` is static for bring-up; ADR-0005 d6 makes it register-provisioned
 * later. Call cyphal_init() once after can_init_normal(), then cyphal_spin()
 * as often as possible from the main loop.
 *
 * `node_name` is the reverse-DNS uavcan.node.GetInfo name and `description` the
 * uavcan.node.description register. Both belong to the strap-selected
 * personality, not to the image -- one image serves every module class
 * (ADR-0017 d16), so these are how the gateway tells an E0002 from an E0006 on
 * the wire. Both must outlive the call; string literals are the intended source. */
void cyphal_init(uint8_t node_id, const char *node_name, const char *description);
void cyphal_spin(void);

/* Publish a pre-serialized message on `subject_id` (a Cyphal port-ID). The
 * caller owns `transfer_id` (one counter per subject) — it is post-incremented
 * and wrapped. Used by the node personality to emit sensor telemetry. */
void cyphal_publish(uint16_t subject_id, uint8_t *transfer_id,
                    const uint8_t *payload, size_t size);

/* The value to put in every uavcan.time.SynchronizedTimestamp field, which is
 * 0 = UNKNOWN until this bus has a synchronization source.
 *
 * That field is a NETWORK-wide time base, not a per-node one. Nothing publishes
 * uavcan.time.Synchronization (subject 7168) here, so each node's only clock is
 * its own monotonic uptime and two nodes' stamps share no origin — node 96 at
 * 1378 s and node 97 at 62 s were describing the same instant. A consumer that
 * aligns samples across nodes, which is exactly what the state estimator of
 * ADR-0016 does, would be silently wrong. The type reserves 0 for "not known",
 * and saying so is the honest answer until a master exists.
 *
 * This is the single seam where that master plugs in: when the gateway begins
 * publishing 7168, this function returns the synchronized value and every
 * publisher inherits it without change. */
uint64_t cyphal_timestamp_usec(void);

/* Report the personality's own health for the next heartbeat. The heartbeat
 * carries the WORSE of this and the skeleton's own assessment, so a personality
 * cannot mask an identity fault and the skeleton cannot mask a sensor fault.
 * Values are uavcan.node.Health constants. Never reported means NOMINAL. */
void cyphal_set_health(uint8_t health);

/* Declare the subjects this personality publishes, for uavcan.node.port.List
 * (subject 7510). The array must outlive the call. Heartbeat and port.List
 * itself are added by the skeleton. Without this a consumer cannot discover
 * what the node emits — ADR-0005 requires the capability. */
void cyphal_declare_publishers(const uint16_t *subject_ids, uint8_t count);

#endif /* IGROW_CYPHAL_CYPHAL_H */
